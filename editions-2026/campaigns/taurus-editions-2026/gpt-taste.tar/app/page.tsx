import { GptTasteHero } from '@/components/GptTasteHero';
import { HorizontalAccordion } from '@/components/HorizontalAccordion';
import { InfiniteMarquee } from '@/components/InfiniteMarquee';

export default function Home() {
  return (
    <main className="overflow-x-hidden bg-void">
      <GptTasteHero backgroundImage="/assets/hero/animated-hero.png" />
      <InfiniteMarquee />
      <HorizontalAccordion />

      <section className="bg-void px-6 py-32 md:px-16">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="font-display text-5xl font-bold uppercase tracking-tight text-parchment md:text-7xl">
            Ready to Ship?
          </h2>
          <p className="mx-auto mt-6 max-w-2xl font-sans text-lg text-parchment/70">
            Deploy the TAURUS EDITIONS design system across four platforms and every campaign surface.
          </p>
          <button className="mt-10 inline-block bg-parchment px-10 py-4 font-mono text-sm uppercase tracking-widest text-void transition-transform hover:-translate-y-[2px]">
            Start Building
          </button>
        </div>
      </section>
    </main>
  );
}
