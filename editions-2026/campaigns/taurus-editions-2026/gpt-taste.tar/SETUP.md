# GPT-Taste Variant Setup

npm install framer-motion gsap @gsap/react lucide-react clsx tailwind-merge
npm install -D tailwindcss@3 postcss autoprefixer

# GSAP ScrollTrigger is included with gsap; register in client components.
