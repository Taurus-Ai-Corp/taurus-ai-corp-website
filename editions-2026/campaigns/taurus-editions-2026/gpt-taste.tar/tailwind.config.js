// Shared TAURUS EDITIONS 2026 Tailwind config.
// Keep brand tokens in one place: simplify-code/shared-tailwind.config.js
module.exports = require('../simplify-code/shared-tailwind.config.js');
