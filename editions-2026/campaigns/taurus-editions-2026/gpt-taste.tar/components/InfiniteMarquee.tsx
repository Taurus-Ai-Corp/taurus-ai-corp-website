'use client';

import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const ITEMS = [
  { label: 'ARQ QUANTUM LLC', sub: 'GRIDERA' },
  { label: 'TAURUS AI CORP - FZCO', sub: 'NEXUS' },
  { label: 'TAURUS AI Corp.', sub: 'BIO-FOUNDRY' },
  { label: 'Entity TBD', sub: 'DEFQUAN' },
  { label: 'taurusai.io', sub: 'CORPORATE' },
  { label: 'q-grid.net', sub: 'GRIDERA' },
  { label: 'nexus.taurusai.io', sub: 'NEXUS' },
  { label: 'bio-foundry.taurusai.io', sub: 'BIO-FOUNDRY' },
];

export function InfiniteMarquee() {
  const trackRef = useRef(null);

  return (
    <section className="overflow-hidden border-y border-parchment/10 bg-ink/30 py-6">
      <div ref={trackRef} className="flex w-max animate-marquee">
        {[...ITEMS, ...ITEMS, ...ITEMS].map((item, idx) => (
          <div
            key={idx}
            className="flex items-center gap-6 px-8"
          >
            <span className="font-mono text-sm uppercase tracking-widest text-parchment/60">
              {item.label}
            </span>
            <span className="font-display text-sm font-bold uppercase tracking-tight text-parchment">
              {item.sub}
            </span>
            <span className="h-1 w-1 rounded-full bg-parchment/20" />
          </div>
        ))}
      </div>
    </section>
  );
}
