'use client';

import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const PLATFORMS = [
  {
    id: 'gridera',
    name: 'GRIDERA',
    color: '#00F0FF',
    entity: 'ARQ QUANTUM LLC',
    bullets: ['ML-DSA-65 / ML-KEM-768', 'Hedera Consensus Audit', 'Jurisdiction cells'],
  },
  {
    id: 'nexus',
    name: 'NEXUS',
    color: '#FF8C42',
    entity: 'TAURUS AI CORP - FZCO',
    bullets: ['Agentic Creative Studio', 'Campaigns + Content', 'nexus.taurusai.io'],
  },
  {
    id: 'biofoundry',
    name: 'BIO-FOUNDRY',
    color: '#39FF14',
    entity: 'TAURUS AI Corp.',
    bullets: ['8-channel EEG + HRV', 'Neuro-Acoustic Coherence', 'bio-foundry.taurusai.io'],
  },
  {
    id: 'defquan',
    name: 'DEFQUAN',
    color: '#FF3B30',
    entity: 'Entity TBD',
    bullets: ['Arctic C4ISR Telemetry', 'Offline Mesh Comms', 'TRESOR Hardware Root'],
  },
];

export function HorizontalAccordion() {
  const [active, setActive] = useState(0);
  const sectionRef = useRef(null);
  const itemsRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        itemsRef.current,
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-void px-6 py-32 md:px-16">
      <div className="mx-auto max-w-7xl">
        <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
          Four Volumes
        </p>
        <h2 className="font-display text-5xl font-bold uppercase tracking-tight text-parchment md:text-7xl">
          Platform Stack
        </h2>

        <div
          ref={itemsRef}
          className="mt-16 flex h-[60vh] flex-col gap-3 md:flex-row"
        >
          {PLATFORMS.map((p, idx) => {
            const isActive = active === idx;
            return (
              <button
                key={p.id}
                onClick={() => setActive(idx)}
                className="group relative flex overflow-hidden border border-parchment/10 bg-ink/40 text-left transition-all duration-700"
                style={{
                  flex: isActive ? 4 : 1,
                }}
              >
                <div
                  className="absolute inset-0 opacity-10 transition-opacity duration-700 group-hover:opacity-20"
                  style={{ backgroundColor: p.color }}
                />
                <div className="relative z-10 flex h-full w-full flex-col justify-between p-6">
                  <div className="flex items-start justify-between">
                    <span
                      className="font-display text-2xl font-bold uppercase tracking-tight md:text-3xl"
                      style={{ color: p.color }}
                    >
                      {p.name}
                    </span>
                    <ChevronRight
                      className="transition-transform duration-500"
                      style={{ color: p.color, transform: isActive ? 'rotate(90deg)' : 'rotate(0deg)' }}
                      size={20}
                    />
                  </div>

                  <div
                    className="overflow-hidden transition-all duration-700"
                    style={{ opacity: isActive ? 1 : 0, maxHeight: isActive ? '300px' : '0px' }}
                  >
                    <p className="mb-4 font-mono text-xs uppercase tracking-widest text-parchment/50">
                      {p.entity}
                    </p>
                    <ul className="space-y-2 font-sans text-sm text-parchment/70">
                      {p.bullets.map((b) => (
                        <li key={b} className="flex items-center gap-2">
                          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: p.color }} />
                          {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
