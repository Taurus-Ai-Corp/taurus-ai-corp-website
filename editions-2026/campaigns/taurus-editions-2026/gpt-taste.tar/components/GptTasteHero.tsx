'use client';

import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Image from 'next/image';

gsap.registerPlugin(ScrollTrigger);

interface GptTasteHeroProps {
  backgroundImage: string;
}

export function GptTasteHero({ backgroundImage }: GptTasteHeroProps) {
  const sectionRef = useRef(null);
  const imgRef = useRef(null);
  const textRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        imgRef.current,
        { scale: 0.9, opacity: 0.4 },
        {
          scale: 1.1,
          opacity: 1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top top',
            end: 'bottom top',
            scrub: 1,
          },
        }
      );
      gsap.fromTo(
        textRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative flex min-h-[100dvh] w-full items-center overflow-hidden bg-void px-6 md:px-16"
    >
      <div className="absolute inset-0 z-0">
        <Image
          ref={imgRef}
          src={backgroundImage}
          alt="TAURUS EDITIONS background"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-void via-void/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-void via-transparent to-void/40" />
      </div>

      <div className="relative z-10 w-full max-w-7xl">
        <div ref={textRef} className="max-w-4xl">
          <p className="mb-5 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
            Quantum-Secure Enterprise Operations
          </p>
          <h1 className="font-display text-[clamp(3.5rem,6vw,6.5rem)] font-bold uppercase leading-[0.9] tracking-tight text-parchment"
          >
            TAURUS
            <span className="mx-4 inline-block h-[0.7em] w-2 align-middle bg-gridera" />
            EDITIONS
          </h1>
          <p className="mt-8 max-w-xl font-sans text-lg leading-relaxed text-parchment/70">
            Four platforms. One industrial editorial system. Infinite campaign surfaces.
          </p>
          <div className="mt-10 flex gap-4">
            <button className="border border-parchment px-6 py-3 font-mono text-xs uppercase tracking-widest text-parchment transition-colors hover:bg-parchment hover:text-void">
              Explore Platforms
            </button>
            <button className="bg-parchment px-6 py-3 font-mono text-xs uppercase tracking-widest text-void transition-colors hover:bg-parchment/80">
              Book Demo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
