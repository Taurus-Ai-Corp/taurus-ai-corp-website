# DESIGN PLAN — TAURUS EDITIONS 2026 (GPT-Taste Variant)

## Python RNG Execution
Simulated deterministic selection (prompt char count 104 % 5 + 1 = 5):
- Hero Layout: Editorial Split (text left, image right, massive negative space)
- Typography Stack: Space Grotesk (display) + Inter (body) + Space Mono (data)
- Component Arsenal:
  1. Inline Typography Images (platform color bars embedded in headings)
  2. Horizontal Accordions (platform expanders)
  3. Infinite Marquee (entity + domain ticker)
- GSAP Paradigms:
  1. Scroll Pinning (left title pinned while platform cards scroll right)
  2. Image Scale & Fade Scroll (hero bg scales from 0.9 to 1.1)

## AIDA Check
- Attention: Hero section with inline color bars and split layout
- Interest: 4-platform horizontal accordion + bento feature grid
- Desire: Scroll-pinned platform showcase with scale/fade backgrounds
- Action: Massive CTA footer with gradient button

## Hero Math Verification
- H1 container: `max-w-6xl` on outer wrapper, `max-w-4xl` on text block
- H1 font: `clamp(3.5rem, 6vw, 6.5rem)` → forces 2-3 lines for "TAURUS EDITIONS"
- No stamp icons, no spam tags under hero

## Bento Density Verification
- Grid: `grid-cols-1 md:grid-cols-4 md:grid-rows-2`
- Cells:
  - Hero cell: col-span-2 row-span-2
  - GRIDERA: col-span-1 row-span-2
  - NEXUS: col-span-1 row-span-1
  - BIO: col-span-1 row-span-1
  - DEFQUAN: col-span-2 row-span-1
- `grid-flow-dense` applied → no empty cells

## Label Sweep & Button Check
- No "SECTION 01", "QUESTION 05", "ABOUT US" meta-labels
- Buttons: white text on black bg, black text on white bg
- All platform names are actual SKUs, not generic placeholders
