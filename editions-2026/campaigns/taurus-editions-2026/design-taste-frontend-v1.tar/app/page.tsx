import { TaurusEditionsHero } from '@/components/TaurusEditionsHero';
import { EditionCard } from '@/components/EditionCard';
import { PlatformBento } from '@/components/PlatformBento';
import { BookIntegration } from '@/components/BookIntegration';
import { CampaignSection } from '@/components/CampaignSection';

export default function Home() {
  return (
    <main className="relative bg-void text-parchment">
      <div className="edition-grid" />

      <TaurusEditionsHero backgroundImage="/assets/hero/animated-hero.png" />

      <PlatformBento
        items={[
          { platformId: 'gridera', image: '/assets/platforms/gridera-grid-floor.png', size: 'large' },
          { platformId: 'nexus', image: '/assets/platforms/nexus-orbital.png', size: 'medium' },
          { platformId: 'biofoundry', image: '/assets/platforms/biofoundry-hex-mesh.png', size: 'medium' },
          { platformId: 'defquan', image: '/assets/platforms/defquan-diamond.png', size: 'large' },
        ]}
      />

      <EditionCard
        platformId="gridera"
        backgroundImage="/assets/platforms/gridera-grid-floor.png"
      />
      <EditionCard
        platformId="nexus"
        backgroundImage="/assets/platforms/nexus-orbital.png"
      />
      <EditionCard
        platformId="biofoundry"
        backgroundImage="/assets/platforms/biofoundry-hex-mesh.png"
      />
      <EditionCard
        platformId="defquan"
        backgroundImage="/assets/platforms/defquan-diamond.png"
      />

      <BookIntegration />
      <CampaignSection />
    </main>
  );
}
