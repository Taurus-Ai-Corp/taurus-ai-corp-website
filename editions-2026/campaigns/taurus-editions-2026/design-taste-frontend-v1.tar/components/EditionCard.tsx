'use client';

import { motion } from 'framer-motion';
import { cn, useInView } from '@/lib/utils';
import { getPlatform, type PlatformId } from '@/lib/platforms';

interface EditionCardProps {
  platformId: PlatformId;
  backgroundImage?: string;
}

export function EditionCard({ platformId, backgroundImage }: EditionCardProps) {
  const platform = getPlatform(platformId);
  const { ref, inView } = useInView(0.2);

  if (!platform) return null;

  const isTaurus = platformId === 'taurus';

  return (
    <section
      ref={ref}
      id={platformId}
      className="edition-section relative flex min-h-[100dvh] items-center overflow-hidden px-6 md:px-16"
    >
      {backgroundImage && (
        <div className="bg-img-layer">
          <div
            className="bg-img"
            style={{ backgroundImage: `url(${backgroundImage})` }}
          />
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(135deg, ${platform.color}30, ${platform.color}10)`,
              mixBlendMode: 'screen',
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-void via-void/80 to-transparent" />
        </div>
      )}

      <div className="relative z-10 w-full max-w-7xl">
        <div
          className={cn(
            'reveal max-w-2xl',
            inView && 'in-view'
          )}
        >
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
            {platform.entity}
          </p>
          <h2
            className="mt-3 font-display text-6xl font-bold uppercase tracking-tight md:text-8xl"
            style={{ color: platform.color }}
          >
            {platform.name}
          </h2>
          <div
            className="platform-bar mt-6"
            style={{ backgroundColor: platform.color, boxShadow: `0 0 24px ${platform.color}` }}
          />
          <p className="mt-6 max-w-md font-sans text-lg leading-relaxed text-parchment/80">
            {platform.description}
          </p>

          <ul className="mt-8 space-y-3 font-sans text-sm text-parchment/70">
            {platform.bullets.map((bullet) => (
              <li key={bullet} className="flex items-start gap-3">
                <span
                  className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full"
                  style={{ backgroundColor: platform.color }}
                />
                {bullet}
              </li>
            ))}
          </ul>

          <p className="mt-8 font-mono text-xs uppercase tracking-widest text-parchment/40">
            {platform.domain}
          </p>
        </div>
      </div>
    </section>
  );
}
