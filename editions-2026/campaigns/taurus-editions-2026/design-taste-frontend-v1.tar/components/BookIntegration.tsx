'use client';

import { cn, useInView } from '@/lib/utils';

const formats = [
  {
    label: 'WHITE PAPER',
    description: 'Deep technical documents with cryptographic proof, code samples, and citation footnotes.',
  },
  {
    label: 'INTERACTIVE REPORT',
    description: 'Scroll-linked data volumes with live compliance matrices and animated charts.',
  },
  {
    label: 'CAMPAIGN BRIEF',
    description: 'One-page creative directives for each platform: audience, angle, asset mix.',
  },
  {
    label: 'NEWSLETTER',
    description: 'Weekly signal digest across all platforms with single-column editorial rhythm.',
  },
  {
    label: 'WEBINAR DECK',
    description: 'Slide system built from the same tokens and typography as the website.',
  },
  {
    label: 'AD CREATIVE',
    description: 'Format-agnostic modular blocks: headline, visual, CTA, legal disclaimer.',
  },
  {
    label: 'BLOG POST',
    description: 'Long-form editorial with marginalia, pull quotes, and chapter dividers.',
  },
  {
    label: 'PUBLISHING CATALOG',
    description: 'Quarterly print-on-demand edition listing every volume, campaign, and release.',
  },
];

export function BookIntegration() {
  const { ref, inView } = useInView(0.15);

  return (
    <section id="book" className="edition-section relative px-6 py-24 md:px-16">
      <div ref={ref} className={cn('reveal mx-auto max-w-7xl', inView && 'in-view')}>
        <p className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
          Real-World Formats
        </p>
        <h2 className="font-display text-5xl font-bold uppercase tracking-tight text-parchment md:text-7xl">
          Book Integration
        </h2>
        <p className="mt-4 max-w-2xl font-sans text-parchment/60">
          The same editorial system scales into every touchpoint: a physical quarterly, a web-native report, a campaign brief, and a webinar deck all share one token set.
        </p>

        <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {formats.map((format) => (
            <article
              key={format.label}
              className="group relative border border-parchment/10 p-6 transition-all duration-300 hover:border-parchment/25 hover:bg-ink/60"
            >
              <div className="mb-4 h-[1px] w-12 bg-parchment/20 transition-all group-hover:w-20 group-hover:bg-gridera" />
              <h3 className="font-display text-xl font-bold uppercase tracking-tight text-parchment">
                {format.label}
              </h3>
              <p className="mt-3 font-sans text-sm leading-relaxed text-parchment/60">
                {format.description}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
