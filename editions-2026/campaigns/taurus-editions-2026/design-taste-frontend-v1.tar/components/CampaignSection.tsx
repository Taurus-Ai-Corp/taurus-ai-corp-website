'use client';

import { cn, useInView } from '@/lib/utils';

const campaigns = [
  {
    platform: 'GRIDERA',
    title: 'Quantum Compliance Quarterly',
    color: '#00F0FF',
    description: 'A jurisdiction-by-jurisdiction report on post-quantum readiness.',
    surfaces: ['White Paper', 'LinkedIn Carousel', 'Webinar'],
  },
  {
    platform: 'NEXUS',
    title: 'Agentic Creative Studio',
    color: '#FF8C42',
    description: 'Showcase AI-generated campaigns with before/after asset split.',
    surfaces: ['Video Ad', 'Landing Page', 'Newsletter'],
  },
  {
    platform: 'BIO-FOUNDRY',
    title: 'Coherence Journal',
    color: '#39FF14',
    description: 'Research briefs on EEG/HRV coherence and pediatric applications.',
    surfaces: ['Blog Series', 'Print Zine', 'Conference Poster'],
  },
  {
    platform: 'DEFQUAN',
    title: 'Arctic Signal Brief',
    color: '#FF3B30',
    description: 'Classified-style briefings on offline mesh and C4ISR telemetry.',
    surfaces: ['PDF Brief', 'Deck', 'Demo Video'],
  },
  {
    platform: 'TAURUS',
    title: 'Editions Catalog',
    color: '#FFFFFF',
    description: 'Quarterly compendium of all platform releases and roadmaps.',
    surfaces: ['Print Catalog', 'Interactive Site', 'Email'],
  },
  {
    platform: 'ALL',
    title: 'Cross-Volume Ads',
    color: '#F4F0E8',
    description: 'Retargeting sequence that rotates platform color and message by segment.',
    surfaces: ['Meta Ads', 'X Ads', 'YouTube Pre-roll'],
  },
];

export function CampaignSection() {
  const { ref, inView } = useInView(0.15);

  return (
    <section id="campaigns" className="edition-section relative px-6 py-24 md:px-16">
      <div ref={ref} className={cn('reveal mx-auto max-w-7xl', inView && 'in-view')}>
        <p className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
          Multi-Platform Campaigns
        </p>
        <h2 className="font-display text-5xl font-bold uppercase tracking-tight text-parchment md:text-7xl">
          Campaign Engine
        </h2>

        <div className="mt-12 grid grid-cols-1 gap-px bg-parchment/10 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign) => (
            <article
              key={campaign.title}
              className="bg-void p-7 transition-colors duration-300 hover:bg-ink"
            >
              <div className="flex items-center justify-between">
                <span
                  className="font-mono text-[10px] uppercase tracking-widest"
                  style={{ color: campaign.color }}
                >
                  {campaign.platform}
                </span>
                <div
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: campaign.color, boxShadow: `0 0 10px ${campaign.color}` }}
                />
              </div>
              <h3 className="mt-4 font-display text-2xl font-bold uppercase tracking-tight text-parchment">
                {campaign.title}
              </h3>
              <p className="mt-2 font-sans text-sm leading-relaxed text-parchment/60">
                {campaign.description}
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                {campaign.surfaces.map((surface) => (
                  <span
                    key={surface}
                    className="border border-parchment/15 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-parchment/50"
                  >
                    {surface}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
