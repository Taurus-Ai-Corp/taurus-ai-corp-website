'use client';

import { motion, useScroll, useTransform, useMotionValue, useSpring } from 'framer-motion';
import { useRef } from 'react';

interface TaurusEditionsHeroProps {
  backgroundImage: string;
}

export function TaurusEditionsHero({ backgroundImage }: TaurusEditionsHeroProps) {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['0%', '18%']);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.12]);
  const rotateX = useTransform(scrollYProgress, [0, 1], [0, 4]);

  return (
    <section
      ref={containerRef}
      className="edition-section relative flex min-h-[100dvh] items-center justify-start overflow-hidden px-6 md:px-16"
    >
      <motion.div
        className="bg-img-layer"
        style={{ y, scale, rotateX, perspective: 1200 }}
      >
        <div
          className="bg-img absolute -top-[5%] -left-[5%] h-[120%] w-[110%] bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${backgroundImage})` }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(135deg, rgba(0,240,255,0.20), rgba(255,140,66,0.15), rgba(57,255,20,0.10), rgba(255,59,48,0.08))',
            mixBlendMode: 'screen',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-void/30 via-transparent to-void" />
      </motion.div>

      <div className="relative z-10 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
            TAURUS AI CORP — OPERATING SYSTEM
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.9] tracking-tight text-parchment md:text-8xl">
            TAURUS
            <span className="ml-3 text-gridera">EDITIONS</span>
          </h1>
          <div
            className="mt-6 h-[3px] w-20"
            style={{
              background:
                'linear-gradient(90deg, #00F0FF 0%, #FF8C42 33%, #39FF14 66%, #FF3B30 100%)',
            }}
          />
          <p className="mt-8 max-w-xl font-sans text-lg leading-relaxed text-parchment/70">
            A quantum-secure enterprise design system for four platforms, one corporate stack, and infinite campaign surfaces.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
