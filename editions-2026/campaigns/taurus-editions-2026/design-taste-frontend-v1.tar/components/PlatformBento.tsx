'use client';

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { cn, useInView } from '@/lib/utils';
import { getPlatform, type PlatformId } from '@/lib/platforms';

interface PlatformBentoProps {
  items: { platformId: PlatformId; image: string; size: 'large' | 'medium' | 'small' }[];
}

export function PlatformBento({ items }: PlatformBentoProps) {
  const containerRef = useRef(null);
  const { ref, inView } = useInView(0.15);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });
  const y = useTransform(scrollYProgress, [0, 1], [40, -40]);

  const getSpan = (size: string) => {
    switch (size) {
      case 'large': return 'col-span-2 row-span-2';
      case 'medium': return 'col-span-1 row-span-2';
      default: return 'col-span-1 row-span-1';
    }
  };

  return (
    <section ref={containerRef} className="edition-section relative px-6 py-24 md:px-16">
      <div ref={ref} className={cn('reveal mx-auto max-w-7xl', inView && 'in-view')}>
        <p className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-parchment/50">
          Platform Surfaces
        </p>
        <h2 className="font-display text-5xl font-bold uppercase tracking-tight text-parchment md:text-7xl">
          Four Volumes
        </h2>

        <motion.div
          className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-4 md:grid-rows-3"
          style={{ y }}
        >
          {items.map((item, idx) => {
            const platform = getPlatform(item.platformId);
            if (!platform) return null;
            return (
              <motion.div
                key={item.platformId}
                className={cn(
                  'group relative overflow-hidden rounded-2xl border border-parchment/10 bg-ink/50 p-6',
                  getSpan(item.size)
                )}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  delay: idx * 0.08,
                  duration: 0.6,
                  ease: [0.16, 1, 0.3, 1],
                }}
                whileHover={{ scale: 0.98 }}
              >
                <div
                  className="absolute inset-0 bg-cover bg-center opacity-40 transition-opacity duration-500 group-hover:opacity-60"
                  style={{ backgroundImage: `url(${item.image})` }}
                />
                <div
                  className="absolute inset-0 transition-colors duration-500"
                  style={{
                    background: `linear-gradient(135deg, ${platform.color}20, transparent)`,
                  }}
                />

                <div className="relative z-10 flex h-full flex-col justify-between">
                  <div>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-parchment/40">
                      {platform.entity}
                    </span>
                    <h3
                      className="mt-2 font-display text-2xl font-bold uppercase tracking-tight md:text-3xl"
                      style={{ color: platform.color }}
                    >
                      {platform.name}
                    </h3>
                  </div>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-parchment/40">
                    {platform.domain}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
