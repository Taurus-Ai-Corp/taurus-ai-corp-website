export type PlatformId = 'taurus' | 'gridera' | 'nexus' | 'biofoundry' | 'defquan';

export interface Platform {
  id: PlatformId;
  name: string;
  entity: string;
  domain: string;
  color: string;
  accentRgb: string;
  description: string;
  bullets: string[];
}

export const PLATFORMS: Platform[] = [
  {
    id: 'taurus',
    name: 'TAURUS AI',
    entity: 'Corporate Holding',
    domain: 'taurusai.io',
    color: '#FFFFFF',
    accentRgb: '255, 255, 255',
    description: 'Operating parent for the quantum-secure enterprise stack.',
    bullets: ['Industrial editorial identity', 'Four platform architecture', 'Unified brand system'],
  },
  {
    id: 'gridera',
    name: 'GRIDERA',
    entity: 'ARQ QUANTUM LLC',
    domain: 'q-grid.net',
    color: '#00F0FF',
    accentRgb: '0, 240, 255',
    description: 'Post-quantum cryptography compliance platform.',
    bullets: ['ML-DSA-65 / ML-KEM-768', 'Hedera Consensus Audit', 'Jurisdiction cells: NA/EU/IN/AE/CA'],
  },
  {
    id: 'nexus',
    name: 'NEXUS',
    entity: 'TAURUS AI CORP - FZCO',
    domain: 'nexus.taurusai.io',
    color: '#FF8C42',
    accentRgb: '255, 140, 66',
    description: 'Agentic creative studio for campaigns, content, and agents.',
    bullets: ['Social + Creative + Intel', 'Campaign orchestration', 'Agentic publishing workflow'],
  },
  {
    id: 'biofoundry',
    name: 'BIO-FOUNDRY',
    entity: 'TAURUS AI Corp.',
    domain: 'bio-foundry.taurusai.io',
    color: '#39FF14',
    accentRgb: '57, 255, 20',
    description: 'Quantum biology neuro-acoustic coherence platform.',
    bullets: ['8-channel EEG + HRV', 'Pediatric ADHD prodrome', 'Neuro-Acoustic Coherence'],
  },
  {
    id: 'defquan',
    name: 'DEFQUAN',
    entity: 'Entity TBD',
    domain: 'defquan.taurusai.io',
    color: '#FF3B30',
    accentRgb: '255, 59, 48',
    description: 'Dual-use defence quantum mesh architecture.',
    bullets: ['Arctic C4ISR telemetry', 'Offline mesh comms', 'TRESOR hardware root'],
  },
];

export function getPlatform(id: PlatformId): Platform | undefined {
  return PLATFORMS.find((p) => p.id === id);
}
