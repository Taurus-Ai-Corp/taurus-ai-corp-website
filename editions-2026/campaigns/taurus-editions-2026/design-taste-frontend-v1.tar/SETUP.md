# TAURUS EDITIONS 2026 — React/Tailwind Setup

This is a spec-only artifact. To run the components:

## 1. Scaffold a Next.js project

npx create-next-app@14 taurus-editions-2026
# OR use existing project

## 2. Install dependencies

npm install framer-motion lucide-react clsx tailwind-merge
npm install -D tailwindcss@3 postcss autoprefixer

## 3. Initialize Tailwind v3

npx tailwindcss init -p

## 4. Configure tailwind.config.js

See: tailwind.config.js in this folder

## 5. Add globals.css

See: globals.css in this folder

## 6. Copy components

- app/page.tsx
- components/TaurusEditionsHero.tsx
- components/PlatformBento.tsx
- components/EditionCard.tsx
- components/BookIntegration.tsx
- components/CampaignSection.tsx
- lib/platforms.ts
