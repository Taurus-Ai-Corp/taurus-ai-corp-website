#!/usr/bin/env python3
"""Generate a TAURUS-branded assessment report PDF from structured data."""
import os, json, subprocess, sys, shutil
from dataclasses import dataclass
from typing import List

@dataclass
class Finding:
    id: str
    severity: str
    domain: str
    title: str

@dataclass
class ReportData:
    report_id: str
    client: str
    platform: str
    jurisdiction: str
    date: str
    summary: str
    findings: List[Finding]
    conclusion: str

LATEX_SPECIAL = {
    chr(92): r'\textbackslash{}',
    '{': r'\{',
    '}': r'\}',
    '$': r'\$',
    '&': r'\&',
    '%': r'\%',
    '#': r'\#',
    '_': r'\_',
    '~': r'\textasciitilde{}',
    '^': r'\textasciicircum{}',
}

def tex_escape(s: str) -> str:
    return ''.join(LATEX_SPECIAL.get(c, c) for c in s)

def load_tokens(path: str) -> dict:
    return json.load(open(path))

def data_to_latex(data: ReportData, tokens: dict, output_tex: str) -> str:
    from string import Template

    accent = tokens['accent']
    bg = tokens['background']
    primary = tokens['primary']
    subtle = tokens['subtle_bg']

    rows = []
    for f in data.findings:
        rows.append(
            f"\\rowcolor{{{subtle}}} "
            f"{tex_escape(f.id)} & {tex_escape(f.severity.upper())} & "
            f"{tex_escape(f.domain)} & {tex_escape(f.title)} \\\\n"
        )

    tmpl = Template(r"""\documentclass[${base_size}pt]{article}
\usepackage[paper=${page_size},margin=${margin}cm]{geometry}
\usepackage{fontspec}
\usepackage{xcolor}
\usepackage{booktabs}
\usepackage{array}
\usepackage{graphicx}
\usepackage{colortbl}
\usepackage{fancyhdr}
\usepackage{lastpage}
\pagecolor{${bg}}
\color{${primary}}
\setmainfont{${font_family}}
\newfontfamily\headingfont{${heading_font}}
\definecolor{accent}{HTML}{${accent_hex}}
\definecolor{subtle}{HTML}{${subtle_hex}}
\definecolor{primary}{HTML}{${primary_hex}}
\arrayrulecolor{primary}
\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0pt}
\fancyfoot[C]{\footnotesize ${footer}}
\begin{document}
\noindent
\begin{minipage}[t]{0.5\textwidth}
{\headingfont\fontsize{${heading_size}}{28}\selectfont TAURUS}\[2mm]
{\headingfont\fontsize{${subheading_size}}{16}\selectfont ${platform} ASSESSMENT}
\end{minipage}%
\begin{minipage}[t]{0.5\textwidth}
\raggedleft
\footnotesize
\textcolor{accent}{REPORT ID}\
${report_id}\[2mm]
\textcolor{accent}{DATE}\
${date}\[2mm]
\textcolor{accent}{JURISDICTION}\
${jurisdiction}
\end{minipage}

\vspace{6mm}
\noindent\textcolor{accent}{\rule{\textwidth}{0.5pt}}
\vspace{4mm}

\noindent
\begin{minipage}[t]{0.5\textwidth}
\textcolor{accent}{CLIENT}\
${client}
\end{minipage}%
\begin{minipage}[t]{0.5\textwidth}
\raggedleft
\textcolor{accent}{PLATFORM}\
${platform}
\end{minipage}

\vspace{8mm}
\noindent{\headingfont\Large SUMMARY}\[2mm]
${summary}

\vspace{8mm}
\noindent{\headingfont\Large FINDINGS}\[3mm]
\begin{tabular}{|>{\raggedright\arraybackslash}p{2cm}|>{\raggedright\arraybackslash}p{2.5cm}|>{\raggedright\arraybackslash}p{3cm}|>{\raggedright\arraybackslash}p{7cm}|}
\hline
\rowcolor{accent}
\textcolor{black}{\textbf{ID}} & \textcolor{black}{\textbf{Severity}} & \textcolor{black}{\textbf{Domain}} & \textcolor{black}{\textbf{Title}} \\\ \hline
${rows}
\end{tabular}

\vspace{8mm}
\noindent{\headingfont\Large CONCLUSION}\[2mm]
${conclusion}

\vfill
\noindent\centering\footnotesize\textcolor{primary}{Page \thepage\ of \pageref{LastPage}}
\end{document}
""")

    latex = tmpl.substitute(
        base_size=tokens['base_size'],
        page_size=tokens['page_size'],
        margin=tokens['margin_cm'],
        bg=bg,
        primary=primary,
        font_family=tokens['font_family'],
        heading_font=tokens['heading_font'],
        accent_hex=accent.lstrip('#'),
        subtle_hex=subtle.lstrip('#'),
        primary_hex=primary.lstrip('#'),
        footer=tex_escape(tokens['footer_legal']),
        heading_size=tokens['heading_size'],
        subheading_size=tokens['subheading_size'],
        platform=tex_escape(data.platform),
        report_id=tex_escape(data.report_id),
        date=tex_escape(data.date),
        jurisdiction=tex_escape(data.jurisdiction),
        client=tex_escape(data.client),
        summary=tex_escape(data.summary),
        conclusion=tex_escape(data.conclusion),
        rows=''.join(rows),
    )
    open(output_tex, 'w').write(latex)
    return output_tex
def compile_tex(tex_path: str) -> str:
    pdf_path = tex_path.replace('.tex', '.pdf')
    result = subprocess.run(
        ['xelatex', '-interaction=nonstopmode', tex_path],
        cwd=os.path.dirname(tex_path),
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print(result.stdout[-2000:])
        print(result.stderr[-500:])
        raise RuntimeError(f"xelatex failed for {tex_path}")
    return pdf_path

def main():
    if not shutil.which('xelatex'):
        print("xelatex not found; install TeX Live or MacTeX.")
        sys.exit(1)
    tokens = load_tokens(os.path.join(os.path.dirname(__file__), 'tokens.json'))
    data = ReportData(
        report_id='GRD-2026-0001',
        client='Enterprise Bank NA',
        platform='GRIDERA|Comply',
        jurisdiction='na',
        date='2026-08-03',
        summary='Post-quantum cryptographic readiness assessment covering TLS certificate inventory, ML-DSA-65 adoption, and ML-KEM-768 key encapsulation across critical production services.',
        findings=[
            Finding('F-01', 'high', 'TLS', 'Certificate chain lacks hybrid KEM'),
            Finding('F-02', 'medium', 'DNS', 'DNSSEC signatures use RSA-2048'),
            Finding('F-03', 'low', 'Code', 'Internal signing uses SHA-256 only'),
        ],
        conclusion='Migrate to ML-DSA-65 and ML-KEM-768 by Q4 2026; prioritize high-severity TLS and DNS findings.'
    )
    tex = os.path.join(os.path.dirname(__file__), 'sample_report.tex')
    data_to_latex(data, tokens, tex)
    pdf = compile_tex(tex)
    print(f"Generated {pdf}")

if __name__ == '__main__':
    main()
