# TAURUS EDITIONS 2026 — Brand-Aware PDF Pipeline

## Files created
- `tokens.json` — TAURUS brand design tokens (colors, typography, layout)
- `generate_report.py` — Direct XeLaTeX generator for assessment reports

## Workflow
1. Edit `tokens.json` to adjust brand lock.
2. Edit the `ReportData` in `generate_report.py` or import it as a library.
3. Run `python3 generate_report.py` to emit `sample_report.pdf`.

## Gate validation
After generation, verify:
- `pdftotext sample_report.pdf - | wc -c` > 200
- `pdfinfo sample_report.pdf | grep Pages` shows expected page count
- Extracted text contains report_id and client name

## Dependencies
- Python 3
- xelatex (TeX Live / MacTeX)
- fontspec-compatible fonts: Inter and Oswald installed on system

## Notes
- Uses direct `.tex` generation, not Markdown→pandoc, for precise layout control.
- Escapes LaTeX special characters automatically.
- Does not use weasyprint (known to hang on macOS).
